#include "Node.hpp"
#include "BinarySearchTree.hpp"
#include <iostream>

using namespace std;

int main() {
    BinarySearchTree<int> mainTree;


    mainTree.insert(6);

    mainTree.insert(5);

    mainTree.insert(7);

    mainTree.insert(1);

    mainTree.insert(2);

    mainTree.insert(9);

    mainTree.insert(3);



    
}