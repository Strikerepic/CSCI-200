

#include "Quadrilateral.h"


using namespace std;

Quadrilateral::Quadrilateral() {
    numVert = 4;
    coordArray = new Coordinate[numVert];
}

