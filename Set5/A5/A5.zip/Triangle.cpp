
#include "Triangle.h"



using namespace std;

Triangle::Triangle() {
    numVert = 3;
    coordArray = new Coordinate[numVert];
}