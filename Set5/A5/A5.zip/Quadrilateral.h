#ifndef QUADRILATERAL_H
#define QUADRILATERAL_H

#include "Polygon.h"

class Quadrilateral : public Polygon {
    public:

    /**
     * @brief sets the number of vertices to be four and allocates the vertex array to hold four coordinates
     * 
     */
    Quadrilateral();

};





#endif