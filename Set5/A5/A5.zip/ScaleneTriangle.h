#ifndef SCALENETRIANGLE_H
#define SCALENETRIANGLE_H

#include "Triangle.h"

class ScaleneTriangle : public Triangle {
    public:
    bool validate() override;


};



#endif