#ifndef PROCESSOR_H
#define PROCESSOR_H

#include <istream>
#include <ostream>

void process_data(std::istream& in, std::ostream& out);

#endif//PROCESSOR_H