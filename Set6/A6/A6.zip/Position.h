#ifndef POSITION_H
#define POSITION_H

struct Position
{
    int r = 0;
    int c = 0;


    Position(int row, int col);
};



#endif