#include "position.h"

Position::Position(int row, int col) {
    r = row;
    c = col;
}